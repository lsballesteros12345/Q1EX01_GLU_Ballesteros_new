/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package q1ex01_glu_ballesteros;

/**
 *
 * @author Acer
 */
public class Q1EX01_GLU_Ballesteros {

    
    public static void main(String[] args) {
        String name1 = "sushi";
        String origin1 = "Japan";
        int numEaten1 = 0;
        
        String name2 = "maki";
        String origin2 = "Japan";
        int numEaten2 = 1;
        
        String name3 = "kimbap";
        String origin3 = "Korea";
        int numEaten3 = 2;
        
        System.out.println("Food 1");
        System.out.println("Food name: " + name1);
        System.out.println("Origin: " + origin1);
        System.out.println("I ate this n times today: " + numEaten1 + "\n");
        
        System.out.println("Food 2");
        System.out.println("Food name: " + name2);
        System.out.println("Origin: " + origin2);
        System.out.println("I ate this n times today: " + numEaten2 + "\n");
        
        System.out.println("Food 3");
        System.out.println("Food name: " + name3);
        System.out.println("Origin: " + origin3);
        System.out.println("I ate this n times today: " + numEaten3 + "\n");
        
        System.out.println("Collectively, I've eaten these foods today n times: " + (numEaten1 + numEaten2 + numEaten3));
        System.out.println("I ate sushi today: " + (numEaten1 > 0));
        System.out.println("I ate more kimbap than maki today: " + (numEaten3 > numEaten2));
    }
    
}
